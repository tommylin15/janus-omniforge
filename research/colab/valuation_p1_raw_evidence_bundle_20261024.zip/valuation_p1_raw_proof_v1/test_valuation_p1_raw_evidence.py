"""Bounded actual frozen evidence and simulated-provider tests, no paid or HTTP calls."""
import csv
import importlib.util
import json
from pathlib import Path
import pytest

MOD=Path(__file__).with_name('valuation_p1_raw_evidence.py')
spec=importlib.util.spec_from_file_location('valuation_p1_raw_evidence',MOD)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
SAMPLES=[{'symbol':'1103','market':'twse','fiscal_quarter':'2022Q4','dataset':'balance',
          'item_standard':'total_assets','prior_status':'VALUE_MISMATCH_REVIEW'},
         {'symbol':'1101','market':'twse','fiscal_quarter':'2023Q1','dataset':'income',
          'item_standard':'net_income','prior_status':'AMBIGUOUS_SOURCE_OR_PREVIOUS_QUARTER'}]


def test_plan_dedup_and_priority():
    plan,mops=m.make_plan(SAMPLES+[dict(SAMPLES[0],item_standard='total_liabilities')]);assert len(plan)==len(mops)==2
    assert plan[0]['symbol']=='1103' and plan[0]['priority']==0
    assert plan[0]['evidence_type'].startswith('FRESH_')


def test_plan_scoped_symbols():
    p,x=m.make_plan(SAMPLES,selected_symbols=['1103']);assert len(p)==len(x)==1

@pytest.mark.parametrize('bad', ['2022Q5','2022-Q4','2022Q0','2022Q4junk'])
def test_invalid_quarter_rejected(bad):
    with pytest.raises(ValueError):m.quarter_end(bad)


def test_no_mass_fetch():
    p,_=m.make_plan(SAMPLES)
    with pytest.raises(ValueError):m.run_fetch(p,Path('/tmp/unrelated'),selected_symbols=['1101','1102','1103'])
    with pytest.raises(ValueError):m.run_fetch(p,Path('/tmp/unrelated'),selected_symbols=['1103'],limit=5)

class Stub:
    status_code=200
    def __init__(self,records):self.raw=json.dumps({'status':200,'data':records},separators=(',',':')).encode()
    def iter_content(self,chunk_size=65536):yield self.raw


def stub_requests(*,value=12):
    calls=[]
    def fake(url,*,params,headers,timeout,stream):
        assert url==m.API and timeout==20 and stream
        assert 'Authorization' not in headers
        calls.append(dict(params));return Stub([{'stock_id':params['data_id'],'date':params['start_date'],
                                          'type':'TotalAssets','value':value,'origin_name':'資產總計'}])
    return fake,calls


def test_fetch_stores_exact_raw_sha_without_token(tmp_path):
    plan,_=m.make_plan(SAMPLES,selected_symbols=['1103'])
    fake,calls=stub_requests()
    a=m.run_fetch(plan,tmp_path,selected_symbols=['1103'],limit=1,transport=fake)
    assert a['executed_requests']==1 and len(calls)==1
    rec=json.loads((tmp_path/'snapshots.json').read_text())[0]
    b=(tmp_path/rec['response_path']).read_bytes()
    assert m.sha(b)==rec['response_sha256']
    assert 'Authorization' not in (tmp_path/'snapshots.json').read_text()
    assert rec['first_publication_utc']=='UNKNOWN' and rec['source_revision_id']=='UNKNOWN'
    again=m.run_fetch(plan,tmp_path,selected_symbols=['1103'],limit=1,transport=fake)
    assert again['executed_requests']==0 and len(calls)==1


def test_http_auth_error_is_not_recorded(tmp_path):
    class Error:status_code=429
    p,_=m.make_plan(SAMPLES,selected_symbols=['1103'])
    with pytest.raises(RuntimeError,match='RATE_LIMIT_429'):
        m.run_fetch(p,tmp_path,selected_symbols=['1103'],limit=1,transport=lambda *a,**kw:Error())
    assert not (tmp_path/'snapshots.json').exists()


def test_extra_bytes_are_rejected(tmp_path):
    class Huge:
        status_code=200
        def iter_content(self,chunk_size):yield b'z'*(m.MAX_RESPONSE_BYTES+1)
    p,_=m.make_plan(SAMPLES,selected_symbols=['1103'])
    with pytest.raises(ValueError,match='OVER_BYTES_BUDGET'):
        m.run_fetch(p,tmp_path,selected_symbols=['1103'],limit=1,transport=lambda *a,**kw:Huge())


def test_reconcile_stays_blocked_even_on_exact_match(tmp_path):
    plan,_=m.make_plan(SAMPLES,selected_symbols=['1103'])
    fake,_=stub_requests(value=12)
    m.run_fetch(plan,tmp_path,selected_symbols=['1103'],limit=1,transport=fake)
    snap=json.loads((tmp_path/'snapshots.json').read_text())
    links=[{'source_id':'finmind','inventory_row_id':'frozenid','symbol':'1103','fiscal_quarter':'2022Q4',
            'dataset':'balance','item_raw':'TotalAssets','value_raw':'12'}]
    x=m.link_rows(links,snap,tmp_path)
    assert x['matched']==1 and x['arithmetic_ready']==0 and x['historical_asof_ready']==0
    row=m.read_csv(tmp_path/'snapshots_field_anchors.csv')[0]
    assert row['historical_pit_verified']=='False' and row['arithmetic_ready']=='False'


def test_changed_value_not_merged(tmp_path):
    plan,_=m.make_plan(SAMPLES,selected_symbols=['1103'])
    fake,_=stub_requests(value=99)
    m.run_fetch(plan,tmp_path,selected_symbols=['1103'],limit=1,transport=fake)
    snap=json.loads((tmp_path/'snapshots.json').read_text())
    x=m.link_rows([{'source_id':'finmind','inventory_row_id':'f','symbol':'1103','fiscal_quarter':'2022Q4',
                    'dataset':'balance','item_raw':'TotalAssets','value_raw':'12'}],snap,tmp_path)
    assert x['changed_value_candidates']==1 and x['arithmetic_ready']==0


def test_tamper_fail_closed(tmp_path):
    plan,_=m.make_plan(SAMPLES,selected_symbols=['1103'])
    fake,_=stub_requests(value=12)
    m.run_fetch(plan,tmp_path,selected_symbols=['1103'],limit=1,transport=fake)
    snap=json.loads((tmp_path/'snapshots.json').read_text())
    (tmp_path/snap[0]['response_path']).write_text('tampered')
    with pytest.raises(ValueError,match='READBACK_MISMATCH'):
        m.link_rows([{'source_id':'finmind','inventory_row_id':'f','symbol':'1103','fiscal_quarter':'2022Q4',
                      'dataset':'balance','item_raw':'TotalAssets','value_raw':'12'}],snap,tmp_path)


def test_real_113_and_1113_integration(tmp_path):
    root=Path('/mnt/data/valuation_p1_evidence_20261024/results')
    if not root.exists():pytest.skip('Previous genuine research inputs are not mounted')
    r=m.build(root/'exception_evidence.csv',root/'source_record_links.csv',tmp_path)
    assert r['exceptions']==113 and r['source_records']==1113 and r['fresh_http_requests_this_run']==0
    assert r['historical_pit_ready_records']==0 and r['accounting_ready_records']==0
    assert r['unique_stock_codes']==['1101','1102','1103','1104','1201']
    assert r['finmind_tasks']>0 and r['mops_evidence_tasks']>0
    assert len(m.read_csv(tmp_path/'finmind_request_plan.csv'))==r['finmind_tasks']

def test_mops_packet_is_hash_preserved_but_not_certified(tmp_path):
    packet=tmp_path/'report.html';packet.write_bytes(b'<html><title>balance</title></html>')
    r=m.ingest_mops_packet(packet,tmp_path/'audit',source_url='https://mops.twse.com.tw/mops/web/t163sb05',
                           symbol='1103',quarter='2022Q4',dataset='balance')
    assert (tmp_path/'audit'/r['relative_path']).read_bytes()==packet.read_bytes()
    assert not r['row_anchor_verified'] and not r['first_publication_verified']
    assert r['raw_sha256']==m.sha(packet.read_bytes())


def test_mops_packet_rejects_lookalike_host(tmp_path):
    p=tmp_path/'report.html';p.write_bytes(b'x')
    with pytest.raises(ValueError,match='ALLOWLISTED'):
        m.ingest_mops_packet(p,tmp_path/'audit',source_url='https://mops.twse.com.tw.attacker.invalid/',
            symbol='1103',quarter='2022Q4',dataset='balance')
