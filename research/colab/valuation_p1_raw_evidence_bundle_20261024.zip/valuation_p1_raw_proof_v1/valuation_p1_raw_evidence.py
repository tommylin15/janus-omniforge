"""Valuation P1 bounded raw-response snapshot acquisition / lineage proof (research-only).

Fresh responses are *not* historical canonical acquisition bytes or original
published revisions. Source-field matching does not certify units/period/scope/PIT.
No canonical, Registry, training, or publication writes.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import os
import re
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urlencode

API = 'https://api.finmindtrade.com/api/v4/data'
VERSION='valuation-p1-raw-response-v1.0.0'
DATASETS={'balance':'TaiwanStockBalanceSheet','income':'TaiwanStockFinancialStatements',
          'cashflow':'TaiwanStockCashFlowsStatement'}
MAX_REQUESTS=4
MAX_SYMBOLS=2
MAX_RESPONSE_BYTES=3_000_000
MAX_RUN_SECONDS=240
PINNED_RELEASE='release-0bbae8d9c1ca7d8d'
READONLY_STATES={'CONSISTENT_1000X_COHORT_ONLY','VALUE_MISMATCH_REVIEW',
                 'AMBIGUOUS_SOURCE_OR_PREVIOUS_QUARTER'}


def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()

def read_csv(p):
    with open(p,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def write_csv(p,rows,fields):
    p.parent.mkdir(parents=True,exist_ok=True)
    with open(p,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def atomic_bytes(path:Path,payload:bytes):
    if path.exists():
        if path.read_bytes()!=payload: raise ValueError('IMMUTABLE_FILE_CONFLICT')
        return
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.partial')
    if tmp.exists():raise ValueError('STALE_PARTIAL_FILE_REQUIRES_INSPECTION')
    try:
        with open(tmp,'xb') as f:f.write(payload);f.flush();os.fsync(f.fileno())
        tmp.rename(path)
    finally:
        if tmp.exists():tmp.unlink()

def quarter_end(q):
    if not re.fullmatch(r'\d{4}Q[1-4]',q):raise ValueError('BAD_QUARTER')
    return q[:4]+'-'+{'1':'03-31','2':'06-30','3':'09-30','4':'12-31'}[q[-1]]

def task_id(symbol,quarter,dataset):
    return 'finmind_'+symbol+'_'+quarter+'_'+dataset

def make_plan(exceptions, *, selected_symbols=None):
    """Plan only exception-scoped calls, prefer four mismatches before others.

    One HTTP request covers all financial fields in a dataset for a stock/quarter.
    No automatic MOPS POST: historical form, statement scope and version must be
    captured/verified separately by a source-specific parser.
    """
    allowed={str(s) for s in selected_symbols} if selected_symbols else None
    finmind={};mops={}
    for ex in exceptions:
        if ex.get('prior_status') not in ('VALUE_MISMATCH_REVIEW','AMBIGUOUS_SOURCE_OR_PREVIOUS_QUARTER'):
            raise ValueError('NON_EXCEPTION_INPUT')
        symbol=str(ex['symbol']);quarter=str(ex['fiscal_quarter']); ds=str(ex['dataset'])
        if allowed is not None and symbol not in allowed:continue
        if not re.fullmatch(r'\d{4,6}',symbol) or ds not in DATASETS:raise ValueError('INVALID_TASK_KEY')
        day=quarter_end(quarter)
        key=(symbol,quarter,ds)
        priority=0 if ex['prior_status']=='VALUE_MISMATCH_REVIEW' else 1
        if key not in finmind or finmind[key]['priority']>priority:
            finmind[key]={'task_id':task_id(*key),'symbol':symbol,'quarter':quarter,'dataset':ds,
              'finmind_dataset':DATASETS[ds],'start_date':day,'end_date':day,'priority':priority,
              'evidence_type':'FRESH_FINMIND_QUERY_NOT_OLD_CANONICAL_RESPONSE',
              'unit_source':'UNKNOWN','scope_source':'UNKNOWN','revision_source':'UNKNOWN',
              'historical_pit':'NOT_VERIFIED'}
        mops[key]={'task_id':'mops_'+symbol+'_'+quarter+'_'+ds,'symbol':symbol,'quarter':quarter,'dataset':ds,
                   'evidence_type':'MOPS_HISTORICAL_ARCHIVE_OR_ORIGINAL_DISCLOSURE_REQUIRED',
                   'scope_source':'UNKNOWN','unit_source':'UNKNOWN','revision_source':'UNKNOWN',
                   'historical_pit':'NOT_VERIFIED'}
        if 'SAME_YEAR_PRIOR_QUARTER_MISSING_OR_AMBIGUOUS' in ex.get('reasons','') and quarter[-1]!='1':
            previous=quarter[:4]+'Q'+str(int(quarter[-1])-1)
            prior_key=(symbol,previous,ds)
            if prior_key not in mops:
                mops[prior_key]={'task_id':'mops_'+symbol+'_'+previous+'_'+ds,
                   'symbol':symbol,'quarter':previous,'dataset':ds,
                   'evidence_type':'MOPS_PRIOR_QUARTER_ARCHIVE_REQUIRED',
                   'scope_source':'UNKNOWN','unit_source':'UNKNOWN','revision_source':'UNKNOWN',
                   'historical_pit':'NOT_VERIFIED'}
    return sorted(finmind.values(),key=lambda r:(r['priority'],r['symbol'],r['quarter'],r['dataset'])), \
           sorted(mops.values(),key=lambda r:(r['symbol'],r['quarter'],r['dataset']))

def call_one(task,out:Path,token:str,*,transport=None):
    """Fetch a bounded *current* provider response. Never logs/saves secrets."""
    import requests
    if transport is None:transport=requests.get
    params={k:task[k] for k in ('start_date','end_date')}
    params['dataset']=task['finmind_dataset'];params['data_id']=task['symbol']
    headers={'Accept':'application/json','User-Agent':'Janus-Research-P1-Source-Audit/1.0'}
    if token:headers['Authorization']='Bearer '+token
    resp=transport(API,params=params,headers=headers,timeout=20,stream=True)
    status=resp.status_code
    if status in (401,403,429):raise RuntimeError('SOURCE_HTTP_AUTH_OR_RATE_LIMIT_'+str(status))
    if status!=200:raise RuntimeError('SOURCE_HTTP_ERROR_'+str(status))
    total=0;parts=[]
    for part in resp.iter_content(chunk_size=65536):
        if not part:continue
        total+=len(part)
        if total>MAX_RESPONSE_BYTES:raise ValueError('SOURCE_RESPONSE_OVER_BYTES_BUDGET')
        parts.append(part)
    payload=b''.join(parts)
    if len(payload)<2:raise ValueError('EMPTY_PROVIDER_RESPONSE')
    try:parsed=json.loads(payload)
    except (UnicodeDecodeError,json.JSONDecodeError) as e:raise ValueError('FINMIND_RESPONSE_NOT_JSON') from e
    if not isinstance(parsed,dict) or not isinstance(parsed.get('data'),list):
        raise ValueError('FINMIND_RESPONSE_SCHEMA_UNEXPECTED')
    if parsed.get('status') not in (200,'200',None):raise ValueError('FINMIND_BODY_ERROR')
    row_count=len(parsed['data']); snap_sha=sha(payload)
    rel='responses/'+task['task_id']+'/'+snap_sha+'.json'
    atomic_bytes(out/rel,payload)
    return {'task_id':task['task_id'],'symbol':task['symbol'],'quarter':task['quarter'],
       'dataset':task['dataset'],'finmind_dataset':task['finmind_dataset'],
       'start_date':task['start_date'],'end_date':task['end_date'],
       'response_sha256':snap_sha,'response_path':rel,'response_bytes':len(payload),
       'response_rows':row_count,'retrieved_utc':datetime.now(timezone.utc).isoformat(),
       'response_http_status':status,'snapshot_kind':'RETRIEVED_NOW_NOT_ORIGINAL_CANONICAL',
       'unit_basis':'UNKNOWN','statement_scope':'UNKNOWN','source_revision_id':'UNKNOWN',
       'first_publication_utc':'UNKNOWN','publication_allowed':False}

def run_fetch(plan,out,*,token='',selected_symbols,limit=MAX_REQUESTS,transport=None):
    if limit<0 or limit>MAX_REQUESTS:raise ValueError('HTTP_REQUEST_BUDGET_EXCEEDED')
    selected=set(selected_symbols)
    if not selected or len(selected)>MAX_SYMBOLS:raise ValueError('STOCK_BUDGET_EXCEEDED')
    # Prevent automatic full-history runs: must opt in with explicit symbols.
    tasks=[t for t in plan if t['symbol'] in selected]
    if len(tasks)==0:raise ValueError('SELECTED_STOCK_NOT_IN_EXCEPTION_PLAN')
    out.mkdir(parents=True,exist_ok=True)
    receipt_path=out/'snapshots.json'
    history=[] if not receipt_path.exists() else json.loads(receipt_path.read_text(encoding='utf-8'))
    if not isinstance(history,list):raise ValueError('INVALID_RECEIPT')
    done={r['task_id'] for r in history}
    fetched=0;start=time.monotonic()
    for task in tasks:
        if task['task_id'] in done:continue
        if fetched>=limit or time.monotonic()-start>MAX_RUN_SECONDS:break
        record=call_one(task,out,token,transport=transport)
        history.append(record)
        # immutable manifest snapshots: append to versioned receipt, current index is replaceable research pointer
        new=json.dumps(history,ensure_ascii=False,indent=2,sort_keys=True).encode()
        atomic_bytes(out/'receipts'/f"{len(history):04d}-{sha(new)}.json",new)
        receipt_path.write_bytes(new)
        fetched+=1
        if transport is None:time.sleep(1.5)
    return {'executed_requests':fetched,'planned_tasks_in_selection':len(tasks),
       'snapshots':len(history),'status':'PARTIAL' if fetched<len([x for x in tasks if x['task_id'] not in done]) else 'PASS',
       'publication_allowed':False}

def ingest_mops_packet(raw_file:Path,out:Path,*,source_url:str,symbol:str,quarter:str,dataset:str):
    """Archive an explicitly provided MOPS byte packet, WITHOUT inferred row/PIT proof.

    The URL is origin-checked; the blob is retained byte-for-byte, SHA pinned.
    A newly downloaded historical page is not the originally collected 2022 payload.
    """
    from urllib.parse import urlparse
    parsed=urlparse(source_url)
    if parsed.scheme!='https' or parsed.hostname not in ('mops.twse.com.tw','mopsfin.twse.com.tw','www.twse.com.tw'):
        raise ValueError('MOPS_SOURCE_URL_NOT_ALLOWLISTED')
    if not re.fullmatch(r'\d{4,6}',symbol) or dataset not in DATASETS:raise ValueError('MOPS_BAD_TARGET')
    quarter_end(quarter)
    if not raw_file.is_file():raise FileNotFoundError('MOPS_PACKET_FILE_MISSING')
    if not 1<=raw_file.stat().st_size<=15_000_000:raise ValueError('MOPS_PACKET_SIZE_INVALID')
    raw=raw_file.read_bytes();h=sha(raw)
    dest=out/'mops_packets'/symbol/quarter/dataset/(h+'.bin')
    atomic_bytes(dest,raw)
    meta={'symbol':symbol,'quarter':quarter,'dataset':dataset,
          'source_url':source_url,'raw_sha256':h,'relative_path':str(dest.relative_to(out)),
          'bytes':len(raw),'captured_utc':datetime.now(timezone.utc).isoformat(),
          'origin_kind':'SUPPLIED_OR_FETCHED_NOW_NOT_PROVEN_SAME_AS_ORIGINAL_CANONICAL',
          'accounting_unit_verified':False,'period_basis_verified':False,
          'statement_scope_verified':False,'revision_verified':False,
          'first_publication_verified':False,'row_anchor_verified':False,
          'publication_allowed':False}
    atomic_bytes(out/'mops_receipts'/(symbol+'_'+quarter+'_'+dataset+'_'+h+'.json'),
                 (json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode())
    return meta

def number(x):
    try:
        n=Decimal(str(x));return n if n.is_finite() else None
    except (TypeError,ValueError,InvalidOperation):return None

def link_rows(source_links,snapshots,out):
    """Match inventory against *fresh* provider snapshots, do NOT promote proof_gate.

    Changes to values are flagged as drift, not overwritten into frozen data.
    """
    by_task={x['task_id']:x for x in snapshots}
    cache={};summary={'matched':0,'no_match':0,'multiple_matches':0,'not_fetched':0,
                       'changed_value_candidates':0,'raw_bytes_verified':0,
                       'arithmetic_ready':0,'historical_asof_ready':0}
    result=[]
    for row in source_links:
        if row['source_id']!='finmind':continue
        task=task_id(row['symbol'],row['fiscal_quarter'],row['dataset'])
        base={'inventory_row_id':row['inventory_row_id'],'symbol':row['symbol'],
              'fiscal_quarter':row['fiscal_quarter'],'dataset':row['dataset'],
              'item_raw':row['item_raw'],'task_id':task,'snapshot_sha256':'',
              'source_field_anchor_count':0,'source_field_anchor_status':'NOT_FETCHED',
              'original_canonical_response_verified':False,'accounting_unit_verified':False,
              'accounting_period_verified':False,'scope_verified':False,'revision_verified':False,
              'historical_pit_verified':False,'arithmetic_ready':False,
              'historical_asof_ready':False,'publication_allowed':False}
        snap=by_task.get(task)
        if snap:
            f=out/snap['response_path']
            if not f.is_file() or sha(f.read_bytes())!=snap['response_sha256']:
                raise ValueError('SNAPSHOT_BYTES_READBACK_MISMATCH')
            summary['raw_bytes_verified']+=1
            if task not in cache:
                x=json.loads(f.read_bytes());cache[task]=x['data']
            qday=quarter_end(row['fiscal_quarter'])
            candidates=[x for x in cache[task] if isinstance(x,dict) and
                  str(x.get('stock_id'))==row['symbol'] and str(x.get('date'))==qday and
                  str(x.get('type'))==row['item_raw']]
            equality=[x for x in candidates if number(x.get('value'))==number(row['value_raw'])]
            base['snapshot_sha256']=snap['response_sha256'];base['source_field_anchor_count']=len(equality)
            if len(equality)==1:
                base['source_field_anchor_status']='CURRENT_SNAPSHOT_EXACT_FIELD_MATCH_NOT_HISTORICAL_PROOF';summary['matched']+=1
            elif len(equality)>1:
                base['source_field_anchor_status']='CURRENT_SNAPSHOT_DUPLICATE_MATCH';summary['multiple_matches']+=1
            else:
                base['source_field_anchor_status']='CURRENT_SNAPSHOT_MISSING_OR_CHANGED'
                summary['no_match']+=1
                if candidates:summary['changed_value_candidates']+=1
        else:summary['not_fetched']+=1
        result.append(base)
    write_csv(out/'snapshots_field_anchors.csv',result,list(result[0]) if result else ['inventory_row_id'])
    return summary

def build(exceptions_file,links_file,out,*,allowed_symbols=None,run_http=False,token='',limit=MAX_REQUESTS,transport=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    ex=read_csv(exceptions_file); links=read_csv(links_file)
    if len(ex)!=113 or len(links)!=1113:raise ValueError('EXPECTED_FROZEN_113_EXCEPTION_1113_LINKS_MISMATCH')
    plan,mops=make_plan(ex,selected_symbols=allowed_symbols)
    write_csv(out/'finmind_request_plan.csv',plan,list(plan[0]) if plan else ['task_id'])
    write_csv(out/'mops_source_evidence_tasks.csv',mops,list(mops[0]) if mops else ['task_id'])
    fetched={'executed_requests':0,'status':'NOT_RUN'}
    if run_http:
        if not allowed_symbols:raise ValueError('EXPLICIT_SYMBOLS_REQUIRED')
        fetched=run_fetch(plan,out,token=token,selected_symbols=allowed_symbols,limit=limit,transport=transport)
    snapshots=json.loads((out/'snapshots.json').read_text(encoding='utf-8')) if (out/'snapshots.json').exists() else []
    link=link_rows(links,snapshots,out)
    receipt={'version':VERSION,'source_release':PINNED_RELEASE,
       'exceptions':len(ex),'source_records':len(links),'unique_stock_codes':sorted({x['symbol'] for x in ex}),
       'finmind_tasks':len(plan),'mops_evidence_tasks':len(mops),
       'fresh_http_requests_this_run':fetched['executed_requests'],'fresh_snapshots_known':len(snapshots),
       'field_anchor_summary':link,'historical_original_response_bytes_recovered':0,
       'accounting_ready_records':0,'historical_pit_ready_records':0,
       'publication_allowed':False,
       'conclusion':'FRESH_PROVIDER_SNAPSHOTS_ONLY_NOT_HISTORICAL_RESPONSE_OR_DISCLOSURE'}
    (out/'raw_evidence_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return receipt

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--exceptions',type=Path,required=True)
    p.add_argument('--links',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--run-fetch',action='store_true')
    p.add_argument('--symbols',nargs='*',default=[])
    p.add_argument('--max-requests',type=int,default=4)
    p.add_argument('--mops-packet',type=Path)
    p.add_argument('--mops-url')
    p.add_argument('--mops-symbol')
    p.add_argument('--mops-quarter')
    p.add_argument('--mops-dataset')
    args=p.parse_args()
    result=build(args.exceptions,args.links,args.out,allowed_symbols=args.symbols or None,
          run_http=args.run_fetch,token=os.getenv('FINMIND_TOKEN',''),limit=args.max_requests)
    if args.mops_packet:
        if not all((args.mops_url,args.mops_symbol,args.mops_quarter,args.mops_dataset)):
            raise ValueError('MOPS_PACKET_REQUIRES_URL_SYMBOL_QUARTER_DATASET')
        result['mops_packet_receipt']=ingest_mops_packet(args.mops_packet,args.out,source_url=args.mops_url,
            symbol=args.mops_symbol,quarter=args.mops_quarter,dataset=args.mops_dataset)
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
